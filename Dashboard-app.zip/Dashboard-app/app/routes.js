"use strict";

angular.module("opsDashboard").config(["$stateProvider", "$urlRouterProvider", function($stateProvider, $urlRouterProvider){

	$urlRouterProvider.otherwise("/login");

	$stateProvider.state("main", {
			url: "/main",
			templateUrl: "app/components/main/main.html",
			title: "Cordova Angular-Material",
			controller: "MainController",
			controllerAs: "main",
    })
	.state("coo-home", {
		url: "/coo-home",
		templateUrl: "app/components/coo-home/coo-home.html",
		title: "Dashboard",
		controller: "CooHomeController",
		controllerAs: "cooHome",
		resolve: {
			dashboardData: function(dashboardService){
				return dashboardService.getDashboardSummary();
			}
		},
		data: {
			userRole: 'Administrator'
		}
  })
	.state("ot-home", {
        url: "/ot-home",
        templateUrl: "app/components/ot-home/ot-home.html",
        title: "Receiving Process Dashboard",
        controller: "otHomeController",
        controllerAs: "otHome",
		data: {
			userRole: 'Receiver'
		}
  })
  .state("sp-home", {
        url: "/sp-home",
        templateUrl: "app/components/sp-home/sp-home.html",
        title: "Supplier Form",
        controller: "spHomeController",
        controllerAs: "spHome",
		data: {
			userRole: 'Administrator'
		}
  })
	.state("login", {
        url: "/login",
        templateUrl: "app/components/login/login.html",
        title: "Dashboard",
        controller: "loginController",
        controllerAs: "login",
		data: {
			userRole: null
		}
  });


}]);
