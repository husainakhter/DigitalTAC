(function() {
	"use strict";

	angular.module("opsDashboard").controller("spHomeController", spHomeController);

	spHomeController.$inject = ['shared', '$sessionStorage', '$state', '$filter', '$window', '$mdSidenav', '$mdComponentRegistry', '$timeout', '$interval','myAppFactoryOM', 'dashboardService'];

	function spHomeController (shared, $sessionStorage, $state, $filter, $window, $mdSidenav, $mdComponentRegistry, $timeout, $interval,myAppFactoryOM, dashboardService) {

		var spCtrl = this;

		spCtrl.auth = shared.info.auth;

		spCtrl.userRole = $state.current.data.userRole;

		spCtrl.toggle = angular.noop;

		spCtrl.title = $state.current.title;
		spCtrl.dashboardSummary = {};
		spCtrl.byApp =	[];
		spCtrl.byPerson =	[];
		spCtrl.bySLACompliance =	[];
		spCtrl.bySLAComplianceApp =	[];
		spCtrl.bySLAComplianceTeam =	[];
		spCtrl.byEscalation =	[];
		spCtrl.byTicketCategories =	[];
		spCtrl.ticketCategoryGroups = [
			{ id: "WTDData", label: 'WTD' },
			{ id: "MTDData", label: 'MTD' },
			{ id: "QTDData", label: 'QTD' },
			{ id: "YTDData", label: 'YTD' }
		];
		spCtrl.selectedApp = { id: "WTDData", name: 'WTD'};
		spCtrl.ticketVolumeByApp = { id: "WTDData", name: 'WTD'};
		spCtrl.selectedTeam = { id: "WTDData", name: 'WTD'};
		spCtrl.ticketVoulmeByApp	 = "WTDData";
  

		spCtrl.escalationBYApplicationDataset = [];
		spCtrl.escalationDataset	=	[];
		spCtrl.catData1 = [];
		spCtrl.catData2 = [];
		spCtrl.catData3 = [];

		spCtrl.onSLAComplianceAppChange = function() {
		 updateSLAComplianceApp();
		};

		function updateSLAComplianceApp(){
		spCtrl.bySLAComplianceApp = spCtrl.bySLACompliance['byApp'][spCtrl.selectedApp.id];
		}

		spCtrl.onSLAComplianceTeamChange = function() {
		 updateSLAComplianceTeam();
		};

		function updateSLAComplianceTeam(){
		spCtrl.bySLAComplianceTeam = spCtrl.bySLACompliance['byPerson'][spCtrl.selectedTeam.id];
		}

		// escalation Chart  Priority
		function escalationByPriority(){
		  var escalationData = spCtrl.byEscalation['byPriority'];
		  spCtrl.escalationDatasetData	=	[];
			for (var j = 0; j < escalationData.length; j++) {
				spCtrl.escalationDatasetData.push({label: escalationData[j]['priority'],data: escalationData[j]['escCount']});
			};
			spCtrl.escalationDataset = spCtrl.escalationDatasetData;

			spCtrl.escalationDataset[0].color = shared.color.orange;
			spCtrl.escalationDataset[1].color = shared.color.blue;
			spCtrl.escalationDataset[2].color = shared.color.lime;
		}
		spCtrl.escalationOptions = angular.merge({
			series: {
				pie: {
					show: true,
					radius: 1,
					label: {
						show: true,
						radius: 3/4,
						formatter: function (label, series) {
							return '<div style="font-size:1rem;text-align:center;padding:2px;color:#fff;">'+Math.round(series.percent)+'%</div>';

						}
					},
					highlight: {
						opacity: 0.2
					},
					stroke: {
						color: '#FFF',
						width: 2
					},
				}
			},
			grid: {
				hoverable: true,
				clickable: true
			},
			legend: {
				container: '.escalation-Chart.legend-container'
			}
		}, shared.pieChartCommonOptions);

		// Escalation by Application
		function escalationByApp(){
		  var escalationByAppData =[];
			spCtrl.byEscalation['byApp'].forEach(function(el,i){
				escalationByAppData.push( [i, el.escCount] );
				spCtrl.escalationBYApplicationOptions.xaxis.ticks.push([i, el.appName]);
			});
			spCtrl.escalationBYApplicationDataset[0].data = escalationByAppData;
		}

		spCtrl.escalationBYApplicationDataset = [angular.merge({}, {
			label: 'Applications',
			color: shared.color.darkgray,
			data: [],
		}, shared.categoryChartCommonData)];
		spCtrl.escalationBYApplicationOptions = angular.merge({
			series: {
				bars: {
					show: true,
					lineWidth: 1,
					fill: 1.0,
					fillColor: shared.color.lightgray,
					//fillColor: { colors: [ { opacity: 0.3 }, { brightness: 0.3, opacity: 0.3 } ] },
					//fillColor: '#2196f3',
					barWidth: 0.6,
					align: 'center'
				},
				highlightColor: 'rgba(255, 255, 255, 0.2)'
			},
			legend: {
				container: '.escalationBYApp-Chart.legend-container'
			},
			xaxis:{
					ticks:[]
				}
		}, shared.chartCommonOptions);

		// Ticket Volume By Application

		spCtrl.ticketVolumeByAppChange = function() {
			updateTicketVolume();
		};
		
		function updateTicketVolume(){
			var ticketVolumeId = spCtrl.ticketVolumeByApp.id;
			spCtrl.catData1 = [];
			spCtrl.catData2 = [];
			var groupData = spCtrl.byTicketCategories[ticketVolumeId];
			groupData.forEach(function(el,i){
				spCtrl.catData1.push( [i, el.raisedCount] );
				spCtrl.catData2.push( [i, el.openCount] );
				spCtrl.ticketVolumeOptions.xaxis.ticks.push([i, el.appName]);
			});
			spCtrl.ticketVolumeDataset[0].data = spCtrl.catData1;
			spCtrl.ticketVolumeDataset[1].data = spCtrl.catData2;
		}

		spCtrl.ticketVolumeDataset = [angular.merge({}, shared.categoryChartCommonData, {
			label: 'Raised',
			data: [],
			color: shared.color.blue,
			bars: {
					show: true,
					order: 1,
					fillColor: shared.color.lightblue,
				},
					valueLabels: {
						//show: true,
						xoffset: -20,
						//yoffset: 0
					}
			}),
			angular.merge({}, shared.categoryChartCommonData, {
				label: 'Open',
				data: [],
				color: shared.color.amber,
				bars: {
					show: true,
					order: 2,
					fillColor: shared.color.lightamber,
				},
				 valueLabels: {
					//font: "Roboto Condensed",
					//fontcolor: '#666',
					//fontsize: '12px',
						xoffset: 20
				}
		})];

		spCtrl.ticketVolumeOptions = angular.merge({
			series: {
				bars: {
					show: true,
					lineWidth: 1,
					fill: 1.0,
					barWidth: 0.2,
				},
				shadowSize: 3,
				highlightColor: 'rgba(255, 255, 255, 0.2)'
			},
			xaxis:{
					ticks:[]
				},
			legend: {
				container: '.ticketVolume-Chart.legend-container'
			}
		}, shared.chartCommonOptions);

		activate();
		// at the bottom of your controller
		function activate () {
			angular.element($window).on('resize', onResize);
			dashboardService.getDashboardSummary().then(function(data) {
				spCtrl.dashboardSummary = data;
			});
			// Factory function for facthing data from OM JSON
			myAppFactoryOM.getData().then(function (responseData) {
				spCtrl.byApp 				= responseData.data[0]['openApproachingSLAs']['byApp'];
				spCtrl.byPerson 			= responseData.data[0]['openApproachingSLAs']['byPerson'];
				spCtrl.byEscalation 		= responseData.data[0]['escalations']['all'];
				spCtrl.byTicketCategories 	= responseData.data[0]['ticketVolume'];
				spCtrl.bySLACompliance 		= responseData.data[0]['resolutionSLACompliance'];

				updateSLAComplianceTeam();
				updateSLAComplianceApp();
				updateTicketVolume();
				escalationByPriority();
				escalationByApp();
			});
		}
		
		function onResize () {
			if($window.innerWidth<=479){
				spCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-5;
				spCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 5;
			}else if($window.innerWidth>479&&$window.innerWidth<=768){
				spCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-8;
				spCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 8;
			}else if($window.innerWidth>=768 && $window.innerWidth<=991){
				spCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-15;
				spCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 15;
			}else if($window.innerWidth>991 && $window.innerWidth<=1280){
				spCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-20;
				spCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 20;
			}			
		}
		
		spCtrl.isOpen = function() { return false };

		$mdComponentRegistry
		.when("right")
		.then( function(sideNav){
		  spCtrl.isOpen = angular.bind( sideNav, sideNav.isOpen );
		  spCtrl.toggle = angular.bind( sideNav, sideNav.toggle );
		});

		spCtrl.toggleRight = function() {
		$mdSidenav("right").toggle()
			.then(function(){
			});
		};

		spCtrl.close = function() {
		$mdSidenav("right").close()
			.then(function(){
			});
		};
				
	}
})();
