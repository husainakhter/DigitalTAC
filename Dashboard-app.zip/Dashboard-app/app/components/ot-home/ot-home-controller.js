(function() {
	"use strict";

	angular.module("opsDashboard").controller("otHomeController", otHomeController);

	otHomeController.$inject = ['shared', '$sessionStorage', '$state', '$filter', '$window', '$mdSidenav', '$mdComponentRegistry', '$timeout', '$interval','myAppFactoryOT', 'dashboardService'];

	function otHomeController (shared, $sessionStorage, $state, $filter, $window, $mdSidenav, $mdComponentRegistry, $timeout, $interval,myAppFactoryOT, dashboardService) {
	
		var otCtrl = this;
		otCtrl.auth = shared.info.auth;
		otCtrl.userRole = $state.current.data.userRole;
		otCtrl.toggle = angular.noop;
		otCtrl.title = $state.current.title;
		otCtrl.dashboardSummary = {};
		otCtrl.observationRoomList =	[];
		otCtrl.byTicketCategories =	[];
		otCtrl.ticketTrendGroups = [
			{ id: "dailyData", label: 'Daily' },
			{ id: "weeklyData", label: 'Weekly' },
			{ id: "monthlyData", label: 'Monthly' },
			{ id: "quarterlyData", label: 'Quarterly' }
		];
		otCtrl.selectedTrendGroup = { id: "dailyData", label: 'Daily'};	
		otCtrl.selectedReceivedList = { id: "dailyData", label: 'Daily'};
		
	
		
		otCtrl.animalUpdateToday	=	[];
		otCtrl.animalListToday	=	[];
		function updateReceivedListFromSupplier(){
			otCtrl.animalListFromSupplier = otCtrl.animalList[otCtrl.selectedReceivedList.id];
		}
		otCtrl.onReceivedListFromSupplierChange = function() {
			updateReceivedListFromSupplier();
		};
		
		otCtrl.onTicketValumeChange = function() {
			updateTicketVolume();
		};
	 	function updateTicketVolume(){
			var ticketVolumeId = otCtrl.selectedTrendGroup.id;
			otCtrl.catData1 = [];
			otCtrl.catData2 = [];
			var groupData = otCtrl.byTicketCategories[ticketVolumeId];
			groupData.forEach(function(el,i){
				otCtrl.catData1.push( [i, el.resolvedCount] );
				otCtrl.catData2.push( [i, el.openCount] );
				otCtrl.ticketVolumeOptions.xaxis.ticks.push([i, el.appName]);
			});
			otCtrl.ticketVolumeDataset[0].data = otCtrl.catData1;
			otCtrl.ticketVolumeDataset[1].data = otCtrl.catData2;
		}

	  // Ticket Voulme By Application
		otCtrl.ticketVolumeDataset = [angular.merge({}, shared.categoryChartCommonData, {
				label: 'Normal',
				data: [],
				color: shared.color.blue,
				bars: {
					show: true,
					order: 1,
					fillColor: shared.color.lightblue
				},
				valueLabels: {
					xoffset: -20
				}
			}),
			angular.merge({}, shared.categoryChartCommonData, {
				label: 'Emergency',
				data: [],
				color: shared.color.amber,
				bars: {
						show: true,
						order: 2,
						fillColor: shared.color.lightamber
					},
					valueLabels: {
						//font: "Roboto Condensed",
						//fontcolor: '#666',
						//fontsize: '12px',
						xoffset: 20,
						//yoffset: 0,
						//show: true
					}
			})
		];

		otCtrl.ticketVolumeOptions = angular.merge({
			series: {
				bars: {
					show: true,
					lineWidth: 1,
					fill: 1.0,
					barWidth: 0.2
				},
				highlightColor: 'rgba(255, 255, 255, 0.2)'
			},
			xaxis: {
				ticks: []
			},
			legend: {
				container: '.ticketVolume-Chart.legend-container'
			}
		}, shared.chartCommonOptions);

	

		activate();	
	  // at the bottom of your controller
		function activate() {
			angular.element($window).on('resize', onResize);
			dashboardService.getDashboardSummary().then(function(data) {
				otCtrl.dashboardSummary = data;
			});

			myAppFactoryOT.getData().then(function (responseData) {

				otCtrl.emergencyRoomList	= responseData.data[0]['emergencyRoomList']['all'];
				otCtrl.observationRoomList	= responseData.data[0]['observationRoomList']['all'];
				otCtrl.lairageRoomList		= responseData.data[0]['lairageRoomList']['all'];
			
				otCtrl.byTicketCategories	= responseData.data[0]['receivedVolume'];
				otCtrl.animalUpdateToday	= responseData.data[0]['animalUpdateToday']['dataArr'];
				otCtrl.animalList			= responseData.data[0]['animalList'];
				updateTicketVolume();
				updateReceivedListFromSupplier();
			});
		}
		
		function onResize() {
			if($window.innerWidth<=479){
				otCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-5;
				otCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 5;
			}else if($window.innerWidth>479&&$window.innerWidth<=768){
				otCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-8;
				otCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 8;
			}else if($window.innerWidth>=768 && $window.innerWidth<=991){
				otCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-15;
				otCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 15;
			}else if($window.innerWidth>991 && $window.innerWidth<=1280){
				otCtrl.ticketVolumeDataset[0].valueLabels.xoffset =-20;
				otCtrl.ticketVolumeDataset[1].valueLabels.xoffset = 20;
			}	
		}
		
		this.toggleRight = toggleRight;
		function toggleRight() {
			$mdSidenav("right").toggle()
				.then(function(){
			});
		};

	}
})();